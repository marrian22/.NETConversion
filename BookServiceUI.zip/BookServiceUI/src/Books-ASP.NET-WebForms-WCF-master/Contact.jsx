import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Contact.css';

function ContactPage() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [submissionStatus, setSubmissionStatus] = useState('');

  // Strategy for .resx resources:
  // For simple cases, hardcode strings. For robust localization,
  // integrate a library like 'react-i18next' or 'formatjs'.
  // Example for react-i18next:
  // import { useTranslation } from 'react-i18next';
  // const { t } = useTranslation();
  // ... then use t('contact.pageTitle') instead of hardcoded strings.

  const handleSubmit = async (event) => {
    event.preventDefault();
    setSubmissionStatus('Submitting...');

    // --- Placeholder for External calls (API calls, DB calls, etc.) ---
    // In legacy ASP.NET, Page_Load or button click handlers might have
    // directly interacted with a database or invoked server-side logic.
    // In React, this typically translates to an asynchronous API call
    // to a backend endpoint (e.g., Node.js, ASP.NET Core API, Python Flask).
    //
    // Example using fetch API:
    /*
    try {
      const response = await fetch('/api/contact', { // Replace with your actual API endpoint
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          // Include authorization headers if necessary
        },
        body: JSON.stringify({ name, email, message }),
      });

      if (response.ok) {
        const result = await response.json(); // Or response.text() if your API returns plain text
        setSubmissionStatus('Message sent successfully!');
        // Clear form fields after successful submission
        setName('');
        setEmail('');
        setMessage('');

        // --- Placeholder for Navigation ---
        // If navigation is required after a successful operation, use useNavigate hook.
        // const navigate = useNavigate(); // Make sure useNavigate is declared at the top level of the component
        // navigate('/thank-you-page'); // Example: navigate to a thank you page
      } else {
        const errorData = await response.json();
        setSubmissionStatus(`Failed to send message: ${errorData.message || 'Unknown error'}`);
      }
    } catch (error) {
      console.error('Submission error:', error);
      setSubmissionStatus('An unexpected error occurred.');
    }
    */

    // Simulate an asynchronous operation (e.g., API call)
    setTimeout(() => {
      const success = Math.random() > 0.1; // 90% chance of success for demo
      if (success) {
        setSubmissionStatus('Message sent successfully!');
        setName('');
        setEmail('');
        setMessage('');
      } else {
        setSubmissionStatus('Failed to send message. Please try again.');
      }
    }, 1500);
  };

  return (
    <div className="contact-page">
      <h1>Contact Us</h1>
      <form onSubmit={handleSubmit} className="contact-form">
        <div className="form-group">
          <label htmlFor="name">Name:</label>
          <input
            type="text"
            id="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
            className="form-control"
            aria-label="Your Name"
          />
        </div>

        <div className="form-group">
          <label htmlFor="email">Email:</label>
          <input
            type="email"
            id="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            className="form-control"
            aria-label="Your Email"
          />
        </div>

        <div className="form-group">
          <label htmlFor="message">Message:</label>
          <textarea
            id="message"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            required
            rows="5"
            className="form-control"
            aria-label="Your Message"
          ></textarea>
        </div>

        <button type="submit" className="submit-button">
          Submit
        </button>

        {submissionStatus && (
          <p className={`submission-status ${submissionStatus.includes('successfully') ? 'success' : 'error'}`}>
            {submissionStatus}
          </p>
        )}
      </form>
    </div>
  );
}

export default ContactPage;