import React from 'react';
import './About.css'; // Import the CSS file for styling

const AboutPage = () => {
    // Mimicking Page_Load:
    // In ASP.NET Web Forms, Page_Load runs on every postback and initial page load.
    // In React, for initial load effects (like fetching data), you'd use useEffect with an empty dependency array.
    // Since the original Page_Load was empty, there's no specific logic to translate here.
    React.useEffect(() => {
        // Placeholder for any initial data fetching or setup that would happen on page load.
        // For example:
        // const fetchData = async () => {
        //     try {
        //         // Example of an external API call
        //         const response = await fetch('/api/about-info');
        //         const data = await response.json();
        //         // setState(data); // If there was state to update
        //     } catch (error) {
        //         console.error("Error fetching about info:", error);
        //     }
        // };
        // fetchData();
        console.log("About page loaded (simulating Page_Load)");
    }, []); // Empty dependency array ensures this runs only once, like initial Page_Load

    // No specific controls declared in Designer.cs or logic in About.aspx.cs
    // assuming a standard static "About Us" page content.

    // Placeholder for navigation logic if there were redirects based on server-side conditions.
    const handleNavigateToHome = () => {
        // Example navigation using React Router's useNavigate hook:
        // import { useNavigate } from 'react-router-dom';
        // const navigate = useNavigate();
        // navigate('/');
        console.log("Navigating to home page (placeholder)");
    };

    return (
        <div className="about-container">
            <h1 className="about-header">About Our Application</h1>
            <p className="about-text">
                Welcome to BooksWebApp! This application is designed to help you manage your book collection
                efficiently. We aim to provide a user-friendly interface for cataloging, searching, and
                organizing your favorite reads.
            </p>
            <p className="about-text">
                Our mission is to bring your physical and digital libraries together in one intuitive platform.
                We are constantly working to improve our features and user experience.
            </p>
            <p className="about-version">
                Version: 1.0.0.0
            </p>
            <p className="about-contact">
                For support, please contact us at support@bookswebapp.com.
            </p>
            {/* Example of a button (if there was one on the original page) */}
            <button className="about-button" onClick={handleNavigateToHome}>
                Back to Home
            </button>
            {/* Strategy for .resx resources:
                For simple strings like "Welcome to BooksWebApp!", they can be hardcoded as above.
                For multi-language support, integrate an i18n library like `react-i18next`.
                Example: <h1 className="about-header">{t('about.header')}</h1>
                Images: Import directly or serve from public folder, e.g., <img src="/images/logo.png" alt="Logo" />
            */}
        </div>
    );
};

export default AboutPage;