// Auto-generated routes
import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import AboutPage from './About'; // Adjust path based on your file structure
import AddPhoneNumber from './AddPhoneNumber'; // Adjust path as necessary based on your file structure
import BooksPage from './Default'; // Assuming BooksPage.jsx is in the same directory
import ConfirmAccount from './Confirm'; // Assuming ConfirmAccount.jsx is in the same directory or a subfolder like 'pages'
import ContactPage from './Contact'; // Adjust the import path as necessary
//import ErrorPage from './Error'; // Placeholder for your error page component
import ForgotPassword from './ResetPassword'; // Adjust path if needed
//import HomePage from './HomePage'; // Placeholder for your home/return URL page
import LockoutPage from './Lockout'; // Placeholder for your lockout page component
//import Login from '../components/Account/Login'; // Assuming you have a Login component that '/login' routes to
import Login from './Login'; // Assuming Login.jsx is in the same directory or adjust path
import ManageLogins from './ManageLogins'; // Assuming ManageLogins.jsx is in the same directory
import ManagePage from './Manage'; // Assuming ManagePage.jsx is in the same directory
import ManagePassword from './ManagePassword'; // Adjust path as needed
import Register from './Register'; // Adjust path if needed
import RegisterExternalLogin from './RegisterExternalLogin'; // Assuming the component file is RegisterExternalLogin.jsx
import ResetPasswordConfirmation from './ResetPasswordConfirmation'; // Adjust this path based on your project structure
import ResetPasswordPage from './ResetPassword'; // Assuming the component is in ResetPasswordPage.jsx
import TwoFactorAuthenticationSignIn from './TwoFactorAuthenticationSignIn'; // Assuming it's in the same directory
import VerifyPhoneNumber from './VerifyPhoneNumber'; // Adjust path as needed

export default function AppRoutes() {
  return (
      <Routes>
        <Route path="/about" element={<AboutPage />} />
        <Route path="/contact" element={<ContactPage />} />
        {/* <Route path="/default" element={<BooksPage />} /> */}
        <Route path="/addphonenumber" element={<AddPhoneNumber />} />
        <Route path="/confirm" element={<ConfirmAccount />} />
        <Route path="/forgot" element={<ForgotPassword />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register/>} />
        <Route path="/account/lockout" element={<div>Account Locked Out</div>} />
        <Route path="/account/twofactorauthenticationsignin" element={<div>Two-Factor Authentication</div>} />
        {/* <Route path="" element={<div>Welcome Home!</div>} /> */}
        <Route path="/" element={<BooksPage />}  />
        <Route path="/manage" element={<ManagePage />} />
        <Route path="/managelogins" element={<ManageLogins />} />
        <Route path="/add-password" element={<div>Add Password Page Placeholder</div>} />
        <Route path="/" element={<div>Welcome Home!</div>} />
        <Route path="/managepassword" element={<ManagePassword />} />
        <Route path="/registerexternallogin" element={<RegisterExternalLogin />} />
        <Route path="/resetpassword" element={<ResetPasswordPage />} />
        <Route path="/resetpasswordconfirmation" element={<ResetPasswordConfirmation />} />
        <Route path="/twofactorauthenticationsignin" element={<TwoFactorAuthenticationSignIn />} />
        {/* <Route path="/account/error" element={<ErrorPage />} /> */}
        <Route path="/account/lockout" element={<LockoutPage />} />
        <Route path="/" element={<Login />} /> {/* Default route, possibly for ReturnUrl="/" */}
        <Route path="/verifyphonenumber" element={<VerifyPhoneNumber />} />
        <Route path="/account/manage" element={<div>Manage Account Page (Redirected here on success)</div>} />
        <Route path="/" element={<div>Home Page</div>} />
        <Route path="*" element={<div>404 Not Found</div>} />
      </Routes>
  );
}
