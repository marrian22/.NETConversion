import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import './ManagePassword.css';

// Placeholder for API services
// In a real application, you would have an authentication service
// that interacts with your backend API.
const authService = {
  // Simulates checking if a user has a password set
  // In a real app, this would be an API call to your backend
  // that queries the user's status.
  async checkUserHasPassword(userId) {
    console.log(`API call: Checking if user ${userId} has password...`);
    // Example: Assume user 1 has password, user 2 doesn't.
    // Replace with actual API call to your backend.
    await new Promise(resolve => setTimeout(resolve, 300)); // Simulate network delay
    return Math.random() > 0.5; // Simulate a random response for demonstration
  },

  // Simulates changing a user's password
  // In a real app, this would be an API call to your backend (e.g., POST /api/account/change-password)
  async changePassword(userId, currentPassword, newPassword) {
    console.log(`API call: Changing password for user ${userId}...`);
    // Replace with actual API call (e.g., axios.post('/api/account/change-password', { userId, currentPassword, newPassword }))
    await new Promise(resolve => setTimeout(resolve, 500)); // Simulate network delay

    // Simulate success/failure
    if (currentPassword === 'CorrectOldPass' && newPassword === 'NewComplexPass') {
      return { succeeded: true };
    } else {
      return { succeeded: false, errors: ['Incorrect current password or new password invalid.'] };
    }
  },

  // Simulates setting a user's password for the first time
  // In a real app, this would be an API call to your backend (e.g., POST /api/account/set-password)
  async addPassword(userId, password) {
    console.log(`API call: Setting password for user ${userId}...`);
    // Replace with actual API call (e.g., axios.post('/api/account/set-password', { userId, password }))
    await new Promise(resolve => setTimeout(resolve, 500)); // Simulate network delay

    // Simulate success/failure
    if (password.length >= 6 && password !== 'invalid') { // Simple validation
      return { succeeded: true };
    } else {
      return { succeeded: false, errors: ['Password must be at least 6 characters.', 'Password cannot be "invalid" (simulated for demo).'] };
    }
  },

  // Simulates signing the user back in after password change (if needed)
  // In a React app, this typically involves re-fetching user data or updating JWT/session.
  async signInUser(userId, isPersistent, rememberBrowser) {
      console.log(`API call: Signing in user ${userId} (isPersistent: ${isPersistent}, rememberBrowser: ${rememberBrowser})...`);
      await new Promise(resolve => setTimeout(resolve, 100)); // Simulate quick sign-in
      // In a real app, this might update a global auth context or re-set tokens
  }
};

// Placeholder for user context/identity
// In a real app, you would use React Context or a global state management library
// (e.g., Redux, Zustand) to manage user authentication state.
const useUserIdentity = () => {
  // For demonstration, assume a hardcoded user ID.
  // In a real app, this would come from an auth context (e.g., JWT token, session).
  return {
    getUserId: () => 'user123', // Replace with dynamic user ID from auth context
  };
};

const ManagePassword = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const userIdentity = useUserIdentity(); // Hook to get user identity

  const [hasPassword, setHasPassword] = useState(false);
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');

  const [setPasswordInput, setSetPasswordInput] = useState(''); // Original `password` in ASPX
  const [confirmSetPasswordInput, setConfirmSetPasswordInput] = useState(''); // Original `confirmPassword` in ASPX

  const [errorMessages, setErrorMessages] = useState([]);
  const [successMessage, setSuccessMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // Equivalent to ASP.NET's Page_Load logic (checking query string, determining sections)
  useEffect(() => {
    const userId = userIdentity.getUserId();
    const queryParams = new URLSearchParams(location.search);
    const message = queryParams.get('m');

    if (message) {
      switch (message) {
        case 'ChangePwdSuccess':
          setSuccessMessage('Your password has been changed.');
          break;
        case 'SetPwdSuccess':
          setSuccessMessage('Your password has been set.');
          break;
        default:
          setSuccessMessage('');
          break;
      }
      // Clean up the query string after displaying the message
      // This is similar to Form.Action = ResolveUrl("~/Account/Manage");
      // navigate(location.pathname, { replace: true }); // Option to clear query param from URL
    }

    const checkPasswordStatus = async () => {
      setIsLoading(true);
      try {
        const userHasPassword = await authService.checkUserHasPassword(userId);
        setHasPassword(userHasPassword);
      } catch (error) {
        console.error("Failed to check password status:", error);
        setErrorMessages(['Failed to load password status. Please try again.']);
      } finally {
        setIsLoading(false);
      }
    };

    checkPasswordStatus();
  }, [location.search, userIdentity]); // Re-run if query params change

  const addErrors = (result) => {
    if (result && result.errors) {
      setErrorMessages(result.errors);
    } else {
      setErrorMessages(['An unknown error occurred.']);
    }
  };

  const validatePasswordFields = (password, confirm) => {
    const errors = [];
    if (!password) {
      errors.push('Password is required.');
    } else if (password.length < 6) { // Example complexity
        errors.push('Password must be at least 6 characters long.');
    }
    if (!confirm) {
      errors.push('Confirm Password is required.');
    }
    if (password && confirm && password !== confirm) {
      errors.push('The password and confirmation password do not match.');
    }
    return errors;
  };

  const handleChangePasswordSubmit = async (e) => {
    e.preventDefault();
    setErrorMessages([]);
    setSuccessMessage('');

    const validationErrors = [];
    if (!currentPassword) {
      validationErrors.push('Current password is required.');
    }
    validationErrors.push(...validatePasswordFields(newPassword, confirmNewPassword));

    if (validationErrors.length > 0) {
      setErrorMessages(validationErrors);
      return;
    }

    setIsLoading(true);
    try {
      const result = await authService.changePassword(
        userIdentity.getUserId(),
        currentPassword,
        newPassword
      );

      if (result.succeeded) {
        await authService.signInUser(userIdentity.getUserId(), false, false); // Re-sign in if needed
        navigate('/managepassword?m=ChangePwdSuccess', { replace: true });
      } else {
        addErrors(result);
      }
    } catch (error) {
      console.error("Change password failed:", error);
      setErrorMessages(['An error occurred while changing your password. Please try again.']);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSetPasswordSubmit = async (e) => {
    e.preventDefault();
    setErrorMessages([]);
    setSuccessMessage('');

    const validationErrors = validatePasswordFields(setPasswordInput, confirmSetPasswordInput);

    if (validationErrors.length > 0) {
      setErrorMessages(validationErrors);
      return;
    }

    setIsLoading(true);
    try {
      const result = await authService.addPassword(userIdentity.getUserId(), setPasswordInput);

      if (result.succeeded) {
        navigate('/managepassword?m=SetPwdSuccess', { replace: true });
      } else {
        addErrors(result);
      }
    } catch (error) {
      console.error("Set password failed:", error);
      setErrorMessages(['An error occurred while setting your password. Please try again.']);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="manage-password-container">
        <p>Loading...</p>
      </div>
    );
  }

  return (
    <div className="manage-password-container">
      <h2>Manage Password</h2>

      {successMessage && (
        <div className="alert success-message" role="alert">
          {successMessage}
        </div>
      )}

      {errorMessages.length > 0 && (
        <div className="alert error-message" role="alert">
          <p>The following errors occurred:</p>
          <ul>
            {errorMessages.map((error, index) => (
              <li key={index}>{error}</li>
            ))}
          </ul>
        </div>
      )}

      {/* Conditional rendering based on whether user has a password */}
      {hasPassword ? (
        <div className="form-section change-password-holder">
          <h3>Change Your Password</h3>
          <form onSubmit={handleChangePasswordSubmit}>
            <div className="form-group">
              <label htmlFor="currentPassword">Current Password:</label>
              <input
                type="password"
                id="currentPassword"
                className="form-control"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                required // HTML5 validation for required
              />
            </div>
            <div className="form-group">
              <label htmlFor="newPassword">New Password:</label>
              <input
                type="password"
                id="newPassword"
                className="form-control"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                required
              />
            </div>
            <div className="form-group">
              <label htmlFor="confirmNewPassword">Confirm New Password:</label>
              <input
                type="password"
                id="confirmNewPassword"
                className="form-control"
                value={confirmNewPassword}
                onChange={(e) => setConfirmNewPassword(e.target.value)}
                required
              />
            </div>
            <button type="submit" className="btn btn-primary">Change Password</button>
          </form>
        </div>
      ) : (
        <div className="form-section set-password">
          <h3>Set Your Password</h3>
          <form onSubmit={handleSetPasswordSubmit}>
            <div className="form-group">
              <label htmlFor="setPasswordInput">New Password:</label>
              <input
                type="password"
                id="setPasswordInput"
                className="form-control"
                value={setPasswordInput}
                onChange={(e) => setSetPasswordInput(e.target.value)}
                required
              />
            </div>
            <div className="form-group">
              <label htmlFor="confirmSetPasswordInput">Confirm New Password:</label>
              <input
                type="password"
                id="confirmSetPasswordInput"
                className="form-control"
                value={confirmSetPasswordInput}
                onChange={(e) => setConfirmSetPasswordInput(e.target.value)}
                required
              />
            </div>
            <button type="submit" className="btn btn-primary">Set Password</button>
          </form>
        </div>
      )}
    </div>
  );
};

export default ManagePassword;