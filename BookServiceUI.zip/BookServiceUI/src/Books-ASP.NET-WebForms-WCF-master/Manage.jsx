import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation, useSearchParams } from 'react-router-dom';
import './Manage.css';

// Placeholder for API service calls
// In a real application, these would be calls to your backend API,
// typically using fetch, axios, or a dedicated data fetching library.
const userService = {
    // Simulates fetching user details from the backend
    getUserAccountInfo: async (userId) => {
        console.log(`[API] Fetching user account info for userId: ${userId}`);
        // Replace with actual API call:
        // const response = await fetch(`/api/user/${userId}/account-info`);
        // if (!response.ok) throw new Error('Failed to fetch user info');
        // const data = await response.json();
        // return data; // Expected structure: { hasPassword: bool, phoneNumber: string, twoFactorEnabled: bool, loginsCount: int }

        // --- MOCK DATA FOR DEVELOPMENT ---
        return new Promise(resolve => setTimeout(() => {
            resolve({
                hasPassword: true, // Simulate user already has a password
                phoneNumber: '123-456-7890', // Simulate a phone number
                twoFactorEnabled: false, // Simulate 2FA status
                loginsCount: 3, // Simulate login count
            });
        }, 500));
    },

    // Simulates removing a phone number via backend API
    removePhoneNumber: async (userId) => {
        console.log(`[API] Removing phone number for userId: ${userId}`);
        // Replace with actual API call:
        // const response = await fetch(`/api/user/${userId}/phone`, { method: 'DELETE' });
        // if (!response.ok) throw new Error('Failed to remove phone number');
        // return response.json(); // Or simply check response.ok
        
        // --- MOCK DATA FOR DEVELOPMENT ---
        return new Promise(resolve => setTimeout(() => resolve({ success: true }), 300));
    },

    // Simulates enabling/disabling two-factor authentication via backend API
    setTwoFactorEnabled: async (userId, enabled) => {
        console.log(`[API] Setting 2FA for userId: ${userId} to: ${enabled}`);
        // Replace with actual API call:
        // const response = await fetch(`/api/user/${userId}/twofactor`, {
        //     method: 'POST',
        //     headers: { 'Content-Type': 'application/json' },
        //     body: JSON.stringify({ enabled })
        // });
        // if (!response.ok) throw new Error('Failed to update 2FA status');
        // return response.json();
        
        // --- MOCK DATA FOR DEVELOPMENT ---
        return new Promise(resolve => setTimeout(() => resolve({ success: true }), 300));
    },
};

const ManagePage = () => {
    const [successMessage, setSuccessMessage] = useState('');
    const [hasPassword, setHasPassword] = useState(false);
    const [phoneNumberDisplay, setPhoneNumberDisplay] = useState('');
    const [hasPhoneNumber, setHasPhoneNumber] = useState(false);
    const [twoFactorEnabled, setTwoFactorEnabled] = useState(false);
    const [loginsCount, setLoginsCount] = useState(0);

    const navigate = useNavigate();
    const location = useLocation();
    const [searchParams] = useSearchParams(); // Hook to easily access query parameters

    // Maps query string 'm' values to display messages
    const messageMap = {
        ChangePwdSuccess: "Your password has been changed.",
        SetPwdSuccess: "Your password has been set.",
        RemoveLoginSuccess: "The account was removed.",
        AddPhoneNumberSuccess: "Phone number has been added.",
        RemovePhoneNumberSuccess: "Phone number was removed."
    };

    // This useEffect hook runs once on component mount, similar to Page_Load's !IsPostBack block
    useEffect(() => {
        const fetchUserData = async () => {
            // In a real application, you would get the current user ID from your authentication context or state.
            // For this example, we'll use a placeholder.
            const currentUserId = 'some-logged-in-user-id'; // Replace with actual user ID from context/store

            try {
                const data = await userService.getUserAccountInfo(currentUserId);
                setHasPassword(data.hasPassword);
                setPhoneNumberDisplay(data.phoneNumber || 'None'); // Display "None" if phone number is empty
                setHasPhoneNumber(!!data.phoneNumber); // true if phoneNumber exists
                setTwoFactorEnabled(data.twoFactorEnabled);
                setLoginsCount(data.loginsCount);

            } catch (error) {
                console.error("Failed to fetch user account info:", error);
                // Handle error (e.g., show an error message to the user)
            }
        };

        // Process query string for success messages
        const messageCode = searchParams.get('m');
        if (messageCode) {
            setSuccessMessage(messageMap[messageCode] || '');
            // Optionally, remove the query parameter from URL after displaying
            // navigate(location.pathname, { replace: true });
        }

        fetchUserData();
    }, [location.search, searchParams]); // Re-run if search params change

    const handleRemovePhone = async () => {
        const currentUserId = 'some-logged-in-user-id'; // Replace with actual user ID
        try {
            await userService.removePhoneNumber(currentUserId);
            // Optionally, if your backend signInManager requires re-signing in, handle that here.
            // For this example, we just redirect.
            navigate('/manage?m=RemovePhoneNumberSuccess');
        } catch (error) {
            console.error("Failed to remove phone number:", error);
            // AddErrors equivalent: display error to user
        }
    };

    const handleTwoFactorDisable = async () => {
        const currentUserId = 'some-logged-in-user-id'; // Replace with actual user ID
        try {
            await userService.setTwoFactorEnabled(currentUserId, false);
            navigate('/manage'); // Redirect to refresh state
        } catch (error) {
            console.error("Failed to disable 2FA:", error);
        }
    };

    const handleTwoFactorEnable = async () => {
        const currentUserId = 'some-logged-in-user-id'; // Replace with actual user ID
        try {
            await userService.setTwoFactorEnabled(currentUserId, true);
            navigate('/manage'); // Redirect to refresh state
        } catch (error) {
            console.error("Failed to enable 2FA:", error);
        }
    };

    return (
        <div className="manage-container">
            <h1>Manage your account</h1>
            {successMessage && (
                <div className="success-message" role="alert">
                    <p>{successMessage}</p>
                </div>
            )}

            <section className="action-section">
                <h2>Change your account settings</h2>
                <hr />
                <dl className="info-list">
                    <dt>Password:</dt>
                    <dd>
                        {hasPassword ? (
                            <a href="/Account/ChangePassword" className="action-link">Change your password</a>
                        ) : (
                            <a href="/Account/SetPassword" className="action-link">Create password</a>
                        )}
                    </dd>
                    <dt>Phone Number:</dt>
                    <dd>
                        <span className="phone-number-display">{phoneNumberDisplay}</span>
                        {hasPhoneNumber ? (
                            <form className="inline-form" onSubmit={(e) => { e.preventDefault(); handleRemovePhone(); }}>
                                <button type="submit" className="action-button danger">Remove</button>
                            </form>
                        ) : (
                            <a href="/Account/AddPhoneNumber" className="action-link">Add a phone number</a>
                        )}
                    </dd>
                    <dt>Two-Factor Authentication:</dt>
                    <dd>
                        <p>
                            {twoFactorEnabled ? 'Enabled' : 'Disabled'}
                        </p>
                        {twoFactorEnabled ? (
                            <form className="inline-form" onSubmit={(e) => { e.preventDefault(); handleTwoFactorDisable(); }}>
                                <button type="submit" className="action-button">Disable</button>
                            </form>
                        ) : (
                            <>
                                <form className="inline-form" onSubmit={(e) => { e.preventDefault(); handleTwoFactorEnable(); }}>
                                    <button type="submit" className="action-button">Enable</button>
                                </form>
                                <a href="/Account/VerifyPhoneNumber" className="action-link verify-link">Set up</a>
                            </>
                        )}
                    </dd>
                    <dt>Registered Logins:</dt>
                    <dd>
                        <a href="/Account/ManageLogins" className="action-link">
                            {loginsCount}
                        </a>
                    </dd>
                </dl>
            </section>
            {/* Note on .resx: In ASP.NET, .resx files are used for localized strings.
                In React, for i18n, you'd typically use a library like react-i18next or FormatJS.
                The current success messages are hardcoded here, but would be replaced with
                translation keys (e.g., {t('changePwdSuccessMessage')}) if i18n was implemented.
            */}
        </div>
    );
};

export default ManagePage;