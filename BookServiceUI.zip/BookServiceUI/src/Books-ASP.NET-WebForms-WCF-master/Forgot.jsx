import React, { useState } from 'react';
import './ForgotPassword.css'; // Import the CSS file

const ForgotPassword = () => {
    const [email, setEmail] = useState('');
    const [errorMessage, setErrorMessage] = useState('');
    const [showForm, setShowForm] = useState(true);
    const [showConfirmation, setShowConfirmation] = useState(false);
    const [isSubmitting, setIsSubmitting] = useState(false);

    // Function to handle form submission
    const handleForgot = async (e) => {
        e.preventDefault(); // Prevent default form submission behavior

        // Client-side validation (equivalent to basic IsValid check)
        if (!email) {
            setErrorMessage('Please enter your email address.');
            return;
        }
        // Basic email format validation (can be more robust with regex)
        if (!/\S+@\S+\.\S+/.test(email)) {
            setErrorMessage('Please enter a valid email address.');
            return;
        }

        setErrorMessage(''); // Clear previous errors
        setIsSubmitting(true); // Set submitting state

        // Simulate API call (replace with actual fetch/axios call to your backend)
        try {
            // Placeholder for API call
            // This would call your backend API endpoint, e.g., /api/account/forgot-password
            // The backend would then perform the logic from Forgot.aspx.cs:
            // - Validate user existence and email confirmation
            // - Generate password reset token
            // - Send email with the reset link
            const response = await fetch('/api/account/forgot-password', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ email }),
            });

            if (response.ok) {
                // If the backend call is successful, hide the form and show confirmation
                setShowForm(false);
                setShowConfirmation(true);
            } else {
                // Handle API errors
                const errorData = await response.json();
                // Localize: "The user either does not exist or is not confirmed."
                // In a real app, this string would come from a localization resource (e.g., i18n JSON file).
                setErrorMessage(errorData.message || "An error occurred. Please try again.");
            }
        } catch (error) {
            console.error("Forgot password API error:", error);
            // Localize: "An unexpected error occurred. Please try again later."
            setErrorMessage("An unexpected error occurred. Please try again later.");
        } finally {
            setIsSubmitting(false); // Reset submitting state
        }
    };

    return (
        <div className="forgot-password-container">
            <h1>Forgot Password</h1>

            {/* loginForm equivalent */}
            {showForm && (
                <div className="login-form">
                    <p>Enter your email. You will receive a reset password link.</p>

                    {/* ErrorMessage equivalent */}
                    {errorMessage && (
                        <div className="error-message-area" role="alert">
                            {/* FailureText equivalent */}
                            <p className="failure-text">{errorMessage}</p>
                        </div>
                    )}

                    <form onSubmit={handleForgot}>
                        <div className="form-group">
                            <label htmlFor="email">Email</label>
                            {/* Email control equivalent */}
                            <input
                                type="email"
                                id="email"
                                name="email"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                placeholder="Enter your email"
                                required
                                aria-describedby="email-error" // For accessibility
                            />
                            {errorMessage && <span id="email-error" className="input-error">{errorMessage}</span>}
                        </div>
                        <button type="submit" className="forgot-button" disabled={isSubmitting}>
                            {isSubmitting ? 'Submitting...' : 'Submit'}
                        </button>
                    </form>
                </div>
            )}

            {/* DisplayEmail equivalent */}
            {showConfirmation && (
                <div className="display-email-confirmation">
                    <p>
                        <strong>Check your email to reset your password.</strong>
                    </p>
                    <p>
                        An email with instructions to reset your password has been sent to the email address you provided.
                        Please check your inbox (and spam folder) for the reset link.
                    </p>
                    {/* Navigation placeholder:
                        You might want to add a link back to the login page or home page.
                        Example: <Link to="/login">Back to Login</Link>
                    */}
                </div>
            )}
        </div>
    );
};

export default ForgotPassword;