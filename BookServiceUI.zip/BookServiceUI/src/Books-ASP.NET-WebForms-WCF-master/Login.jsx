import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation, Link } from 'react-router-dom';
import './Login.css'; // Import the CSS file

const Login = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [rememberMe, setRememberMe] = useState(false);
    const [errorMessage, setErrorMessage] = useState('');
    const [showError, setShowError] = useState(false);
    const [registerLink, setRegisterLink] = useState('/register'); // Default register URL
    const [openAuthReturnUrl, setOpenAuthReturnUrl] = useState(''); // For OpenAuthLogin component

    const navigate = useNavigate();
    const location = useLocation();

    // Corresponds to Page_Load in ASP.NET
    useEffect(() => {
        const queryParams = new URLSearchParams(location.search);
        const returnUrl = queryParams.get('ReturnUrl');

        if (returnUrl) {
            // Encode the return URL if needed, though navigate handles it often
            const encodedReturnUrl = encodeURIComponent(returnUrl);
            setRegisterLink(`/register?ReturnUrl=${encodedReturnUrl}`);
            setOpenAuthReturnUrl(encodedReturnUrl); // Pass to OpenAuthLogin if it were a real component
        } else {
            setRegisterLink('/register');
            setOpenAuthReturnUrl('');
        }

        // Potential for ForgotPasswordHyperLink if needed in future
        // For now, no ForgotPasswordHyperLink in this example.
    }, [location.search]);

    // Corresponds to LogIn(object sender, EventArgs e) in ASP.NET
    const handleLogin = async (event) => {
        event.preventDefault(); // Prevent default form submission

        // Basic client-side validation (corresponds to IsValid in ASP.NET, if client-side)
        if (!email || !password) {
            setErrorMessage('Email and password are required.');
            setShowError(true);
            return;
        }

        // Simulate server-side validation and authentication
        // This is where you would make an API call to your backend.
        // Replace with actual API endpoint and logic.
        try {
            // Placeholder for API call:
            // const response = await fetch('/api/account/login', {
            //     method: 'POST',
            //     headers: {
            //         'Content-Type': 'application/json',
            //     },
            //     body: JSON.stringify({ email, password, rememberMe }),
            // });

            // const data = await response.json();

            // Simulate different SignInStatus results
            // For demonstration, let's use a hardcoded delay and specific inputs
            const simulatedResult = await new Promise(resolve => {
                setTimeout(() => {
                    // In a real app, this would be data.status or similar from your backend
                    // Example: if (data.success) { resolve('Success'); } else if (data.lockedOut) { resolve('LockedOut'); } etc.
                    if (email === 'test@example.com' && password === 'Password123!') {
                        // Simulate success
                        resolve('Success');
                    } else if (email === 'locked@example.com') {
                        // Simulate locked out
                        resolve('LockedOut');
                    } else if (email === '2fa@example.com') {
                        // Simulate RequiresVerification
                        resolve('RequiresVerification');
                    } else {
                        // Simulate failure
                        resolve('Failure');
                    }
                }, 700); // Simulate network delay
            });

            const returnUrlParam = new URLSearchParams(location.search).get('ReturnUrl');

            switch (simulatedResult) {
                case 'Success':
                    // IdentityHelper.RedirectToReturnUrl(Request.QueryString["ReturnUrl"], Response);
                    navigate(returnUrlParam || '/'); // Redirect to return URL or home page
                    break;
                case 'LockedOut':
                    // Response.Redirect("/Account/Lockout");
                    navigate('/account/lockout');
                    break;
                case 'RequiresVerification':
                    // Response.Redirect(String.Format("/Account/TwoFactorAuthenticationSignIn?ReturnUrl={0}&RememberMe={1}",
                    //                                     Request.QueryString["ReturnUrl"],
                    //                                     RememberMe.Checked),
                    //                   true);
                    navigate(`/account/twofactorauthenticationsignin?ReturnUrl=${encodeURIComponent(returnUrlParam || '')}&RememberMe=${rememberMe}`);
                    break;
                case 'Failure':
                default:
                    // FailureText.Text = "Invalid login attempt"; ErrorMessage.Visible = true;
                    setErrorMessage('Invalid login attempt'); // Hardcoded string, consider i18n.
                    setShowError(true);
                    break;
            }
        } catch (error) {
            console.error('Login error:', error);
            setErrorMessage('An unexpected error occurred. Please try again.');
            setShowError(true);
        }
    };

    return (
        <div className="login-container">
            <h1>Log In</h1>

            <form onSubmit={handleLogin} className="login-form">
                {/* ErrorMessage control (PlaceHolder) and FailureText (Literal) */}
                {showError && (
                    <div id="ErrorMessage" className="error-message">
                        <p id="FailureText">{errorMessage}</p>
                    </div>
                )}

                <div className="form-group">
                    <label htmlFor="Email">Email</label>
                    <input
                        type="email"
                        id="Email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                        aria-label="Email"
                    />
                </div>

                <div className="form-group">
                    <label htmlFor="Password">Password</label>
                    <input
                        type="password"
                        id="Password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                        aria-label="Password"
                    />
                </div>

                <div className="form-group-checkbox">
                    <input
                        type="checkbox"
                        id="RememberMe"
                        checked={rememberMe}
                        onChange={(e) => setRememberMe(e.target.checked)}
                        aria-label="Remember Me"
                    />
                    <label htmlFor="RememberMe">Remember me?</label>
                </div>

                <button type="submit" className="login-button">Log in</button>
            </form>

            <div className="login-links">
                {/* RegisterHyperLink */}
                <Link id="RegisterHyperLink" to={registerLink} className="register-link">Register as a new user</Link>

                {/* OpenAuthLogin control (Placeholder for external authentication providers) */}
                {/* This would typically be a separate component that handles Google, Facebook, etc. logins. */}
                {/* It would receive `openAuthReturnUrl` as a prop if it needed to redirect after successful auth. */}
                <div id="OpenAuthLogin" className="open-auth-providers">
                    <p>Use another service to log in.</p>
                    {/* Placeholder for social login buttons */}
                    <button className="social-login-button google">Login with Google</button>
                    <button className="social-login-button facebook">Login with Facebook</button>
                    {/* You would integrate actual social login SDKs here */}
                </div>
            </div>

            {/* Note on .resx resources: */}
            {/* All hardcoded strings like "Log In", "Email", "Password", "Remember me?", */}
            {/* "Invalid login attempt", "Register as a new user", "Use another service to log in." */}
            {/* would typically be managed using an internationalization (i18n) library like react-i18next. */}
            {/* This allows for easy translation and management of text across different languages. */}
            {/* Example: <p>{t('login.invalidLoginAttempt')}</p> */}
        </div>
    );
};

export default Login;