import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import './VerifyPhoneNumber.css'; // Import the CSS file

const VerifyPhoneNumber = () => {
    const location = useLocation();
    const navigate = useNavigate();

    // State for form fields
    const [phoneNumber, setPhoneNumber] = useState('');
    const [code, setCode] = useState('');

    // State for UI messages
    const [errorMessage, setErrorMessage] = useState('');
    const [isLoading, setIsLoading] = useState(false); // To indicate API call is in progress

    useEffect(() => {
        // Equivalent to Page_Load in ASP.NET
        // Read PhoneNumber from query string
        const params = new URLSearchParams(location.search);
        const pn = params.get('PhoneNumber');

        if (pn) {
            setPhoneNumber(pn);
            // In ASP.NET, manager.GenerateChangePhoneNumberToken was called here.
            // In a modern React app, this token generation typically happens on the server
            // *before* redirecting the user to this page, potentially sending an SMS.
            // The client-side React app only needs to receive the 'PhoneNumber' and then
            // send the 'Code' back to the server for verification.
            // No direct client-side equivalent for GenerateChangePhoneNumberToken.
        } else {
            // If PhoneNumber is missing, show an error or redirect
            setErrorMessage('Phone number not found in the URL. Please go back and try again.');
            // Optionally, navigate away if essential data is missing
            // navigate('/account/manage?m=MissingPhoneNumberError');
        }
    }, [location.search, navigate]);

    const handleCodeChange = (e) => {
        setCode(e.target.value);
        setErrorMessage(''); // Clear error message when user starts typing
    };

    const handleSubmit = async (e) => {
        e.preventDefault(); // Prevent default form submission behavior

        // Client-side validation (equivalent to !ModelState.IsValid for basic checks)
        if (!code.trim()) {
            setErrorMessage('Verification code is required.'); // Localization: Consider using a localization library like react-i18next here
            return;
        }

        setIsLoading(true);

        try {
            // Placeholder for API call to verify phone number
            // This API call will handle the server-side logic of manager.ChangePhoneNumber and signInManager.SignIn
            const response = await fetch('/api/account/verifyphonenumber', { // Example API endpoint
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    // Include authentication token if the API requires it (e.g., from context, local storage)
                    // 'Authorization': `Bearer ${localStorage.getItem('authToken')}`
                },
                body: JSON.stringify({
                    phoneNumber: phoneNumber, // Send the hidden phone number
                    code: code,               // Send the entered code
                    // If user ID is needed, it should be derived from the auth token on the server
                }),
            });

            if (response.ok) {
                // Equivalent to result.Succeeded and signInManager.SignIn
                // Assuming the backend API handles the phone number change and updates the user session/token.
                // Redirect to success page
                navigate('/account/manage?m=AddPhoneNumberSuccess'); // Equivalent to Response.Redirect
            } else {
                // Equivalent to ModelState.AddModelError or other server-side errors
                const errorData = await response.json(); // Assume API returns JSON with an error message
                setErrorMessage(errorData.message || 'Failed to verify phone. Please check your code and try again.'); // Localization
            }
        } catch (error) {
            console.error('Error verifying phone number:', error);
            setErrorMessage('An unexpected error occurred. Please try again later.'); // Localization
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="verify-phone-container">
            <h1>Verify Phone Number</h1>

            {errorMessage && (
                <div className="error-message">
                    {errorMessage}
                </div>
            )}

            <form onSubmit={handleSubmit}>
                {/* Hidden field for PhoneNumber - retains value from query string */}
                <input type="hidden" id="PhoneNumber" value={phoneNumber} />

                <div className="form-group">
                    <label htmlFor="Code">Verification Code</label>
                    <input
                        type="text" // Or type="number" if code is purely numeric
                        id="Code"
                        className="form-control"
                        value={code}
                        onChange={handleCodeChange}
                        disabled={isLoading}
                        required
                        aria-describedby="codeHelp"
                    />
                    <small id="codeHelp" className="form-text text-muted">Enter the code sent to your phone.</small>
                </div>

                <button type="submit" className="btn btn-primary" disabled={isLoading}>
                    {isLoading ? 'Verifying...' : 'Submit Code'}
                </button>
            </form>

            {/*
            Localization Strategy:
            For strings like "Verify Phone Number", "Verification code is required.", etc.:
            1. Hardcode them as done above for simplicity.
            2. Use a localization library like `react-i18next` or `formatjs`.
               Example with react-i18next: `<h1>{t('verifyPhoneNumber.title')}</h1>`
               This requires setting up translation files (e.g., JSON) where keys map to values for different languages.
            */}
        </div>
    );
};

export default VerifyPhoneNumber;