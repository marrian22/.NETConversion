import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import './Register.css';

const Register = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [errorMessage, setErrorMessage] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    const navigate = useNavigate();
    const [searchParams] = useSearchParams();

    // Placeholder for API service - In a real application, this would be a separate file/module
    // e.g., src/services/authService.js
    const authService = {
        register: async (email, password) => {
            // Simulate API call delay
            await new Promise(resolve => setTimeout(resolve, 1000));

            // --- API Call Placeholder ---
            // Replace this with an actual API call to your backend, e.g.:
            /*
            const response = await fetch('/api/account/register', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ email, password }),
            });

            if (!response.ok) {
                const errorData = await response.json();
                // Assuming your backend sends an object like { errors: ["Error message"] }
                throw new Error(errorData.errors?.[0] || 'Registration failed.');
            }

            // Assuming successful registration also logs the user in or returns user info
            const userData = await response.json();
            return { success: true, user: userData };
            */

            // --- Mock API Response for demonstration ---
            if (email === 'test@example.com') {
                throw new Error('User with this email already exists. Please try a different email.');
            }
            if (!email || !password || !confirmPassword) {
                throw new Error('All fields are required.');
            }
            if (password.length < 6) {
                throw new Error('Password must be at least 6 characters long.');
            }

            // Simulate successful registration
            return { success: true, user: { id: 'user-123', email: email, userName: email } };
            // --- End Mock API Response ---
        },
        signIn: async (user) => {
            // Simulate API call for sign-in after successful registration
            await new Promise(resolve => setTimeout(resolve, 500));
            // --- API Call Placeholder ---
            // In a real application, you might have a separate login endpoint for this,
            // or the register endpoint could return a token directly.
            // For now, we simulate a successful sign-in.
            /*
            const response = await fetch('/api/account/signin', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ userId: user.id }), // Or session/token info
            });

            if (!response.ok) {
                throw new Error('Auto-sign-in failed.');
            }
            // Store token/session info (e.g., in localStorage)
            */
            console.log(`User ${user.email} signed in successfully.`);
            return { success: true };
            // --- End API Call Placeholder ---
        }
    };

    const handleRegister = async (event) => {
        event.preventDefault();
        setErrorMessage(''); // Clear previous errors
        setIsLoading(true);

        if (password !== confirmPassword) {
            setErrorMessage('The password and confirmation password do not match.');
            setIsLoading(false);
            return;
        }

        try {
            // Register the user
            const registerResult = await authService.register(email, password);

            if (registerResult.success) {
                // If registration is successful, automatically sign them in
                const signInResult = await authService.signIn(registerResult.user);
                if (signInResult.success) {
                    // Get return URL from query string, similar to ASP.NET IdentityHelper.RedirectToReturnUrl
                    const returnUrl = searchParams.get('ReturnUrl') || '/'; // Default to home page
                    navigate(returnUrl);
                } else {
                    setErrorMessage('Registration successful, but auto-sign-in failed.');
                }
            }
        } catch (error) {
            // Handle specific errors from the backend or network issues
            setErrorMessage(error.message || 'An unexpected error occurred during registration.');
        } finally {
            setIsLoading(false);
        }
    };

    // Strategy for .resx resources / hardcoded strings:
    // For small apps, hardcoding strings is fine.
    // For localization:
    // 1. Use an i18n library (e.g., react-i18next, FormatJS).
    // 2. Define messages in JSON files (e.g., en.json, es.json).
    // 3. Import and use a `useTranslation` hook or `FormattedMessage` component.
    // Example: <h2>{t('register.title')}</h2> instead of <h2>Register</h2>
    const strings = {
        registerTitle: "Register",
        emailLabel: "Email",
        passwordLabel: "Password",
        confirmPasswordLabel: "Confirm Password",
        registerButton: "Register",
        loadingMessage: "Registering..."
    };


    return (
        <div className="register-container">
            <h2>{strings.registerTitle}</h2>
            {errorMessage && <div className="error-message" aria-live="polite">{errorMessage}</div>}
            <form onSubmit={handleRegister}>
                <div className="form-group">
                    <label htmlFor="email">{strings.emailLabel}</label>
                    <input
                        type="email"
                        id="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                        aria-describedby="email-error" // If you want to link to email-specific error later
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="password">{strings.passwordLabel}</label>
                    <input
                        type="password"
                        id="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="confirmPassword">{strings.confirmPasswordLabel}</label>
                    <input
                        type="password"
                        id="confirmPassword"
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        required
                    />
                </div>
                <div className="form-group">
                    <button type="submit" disabled={isLoading}>
                        {isLoading ? strings.loadingMessage : strings.registerButton}
                    </button>
                </div>
            </form>
        </div>
    );
};

export default Register;