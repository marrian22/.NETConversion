import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation, useSearchParams } from 'react-router-dom';
import './RegisterExternalLogin.css';

// Placeholder for an authentication context/hook
// In a real application, this would provide global auth state and functions
const useAuth = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false); // Example: derived from a JWT or session
  const userId = "mock-user-id-123"; // Example: actual user ID from auth state

  // Simulate checking authentication status (e.g., by checking for a token in localStorage)
  useEffect(() => {
    const token = localStorage.getItem('authToken');
    if (token) {
      setIsAuthenticated(true);
    } else {
      setIsAuthenticated(false);
    }
  }, []);

  return { isAuthenticated, userId, login: () => {}, logout: () => {} }; // Add actual login/logout funcs
};

// Placeholder for API service calls
// In a real application, these would be fetch/axios calls to your backend API
const apiService = {
  // Simulates getting external login info after a redirect from an OAuth provider
  // In a real scenario, this might take a 'code' or 'state' from query params
  // and exchange it with the backend to get the actual login info.
  getLoginInfo: async (providerName, returnUrl, xsrfKey, userId) => {
    console.log("API: Fetching external login info for:", providerName, "ReturnUrl:", returnUrl, "XsrfKey:", xsrfKey, "UserId:", userId);
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 500));
    // Simulate successful retrieval of login info
    if (providerName === 'Google' || providerName === 'Facebook') {
      return {
        login: {
          LoginProvider: providerName,
          ProviderKey: "mock-provider-key-123",
          UserName: "testuser",
        },
        email: `user.${Math.random().toString(36).substring(7)}@example.com`, // Simulate dynamic email
      };
    }
    return null; // Simulate failure
  },
  findUser: async (loginInfo) => {
    console.log("API: Finding user with login info:", loginInfo);
    await new Promise(resolve => setTimeout(resolve, 300));
    // Simulate user not found to trigger registration path
    return null; // Return { id: "user-id", email: "existing@example.com" } if found
  },
  signInUser: async (user, isPersistent, rememberBrowser) => {
    console.log("API: Signing in user:", user, isPersistent, rememberBrowser);
    await new Promise(resolve => setTimeout(resolve, 300));
    // Simulate successful sign-in (e.g., backend sets cookie/returns token)
    localStorage.setItem('authToken', 'mock-jwt-token'); // Simulate setting token
    return { success: true };
  },
  addLoginToUser: async (userId, loginInfo) => {
    console.log("API: Adding login to user:", userId, loginInfo);
    await new Promise(resolve => setTimeout(resolve, 300));
    // Simulate success
    return { succeeded: true, errors: [] };
  },
  createUser: async (user, loginInfo) => {
    console.log("API: Creating user and adding login:", user, loginInfo);
    await new Promise(resolve => setTimeout(resolve, 500));
    // Simulate success
    return { succeeded: true, errors: [] };
  },
};

const IdentityHelper = {
    // In React, providerName typically comes from a query parameter from the external login callback
    getProviderNameFromRequest: (searchParams) => {
        // Example: /registerexternallogin?provider=Google
        return searchParams.get('provider') || '';
    },
    // In React, this means using useNavigate to redirect
    redirectToReturnUrl: (returnUrl, navigate) => {
        const defaultUrl = '/'; // Fallback if no returnUrl
        navigate(returnUrl || defaultUrl);
    },
    // For client-side, XsrfKey is less relevant as it's typically server-side
    // For linking accounts, the backend would verify the authenticity of the request.
    XsrfKey: "XsrfId", // Placeholder
    // This is typically handled by the backend after external login, then redirects to frontend
    // GetExternalLoginInfo from Context.GetOwinContext().Authentication
    // In React, assume the backend has processed and redirected back with necessary info
    // or we fetch it based on some query parameter.
    GetExternalLoginInfo: async (params, queryKey, userId) => {
        // Mock implementation: depends on how your backend sends this info
        // e.g., if the backend redirects back with provider and provider key
        const providerName = params.get('provider');
        const providerKey = params.get('provider_key'); // or some other identifier
        const email = params.get('email'); // or fetch from backend
        
        if (providerName && providerKey) {
            return {
                Login: {
                    LoginProvider: providerName,
                    ProviderKey: providerKey,
                },
                Email: email,
            };
        }
        return null;
    }
};


function RegisterExternalLogin() {
    const navigate = useNavigate();
    const location = useLocation();
    const [searchParams] = useSearchParams();
    const { isAuthenticated, userId } = useAuth(); // Get auth state

    const [providerName, setProviderName] = useState('');
    const [providerAccountKey, setProviderAccountKey] = useState('');
    const [email, setEmail] = useState('');
    const [errors, setErrors] = useState([]);
    const [isLoading, setIsLoading] = useState(true); // To show loading state

    const returnUrl = searchParams.get('ReturnUrl');

    const redirectOnFail = () => {
        const redirectTo = isAuthenticated ? '/account/manage' : '/account/login';
        navigate(redirectTo);
    };

    useEffect(() => {
        const processExternalLogin = async () => {
            setIsLoading(true);
            setErrors([]);

            const currentProviderName = IdentityHelper.getProviderNameFromRequest(searchParams);
            if (!currentProviderName) {
                redirectOnFail();
                setIsLoading(false);
                return;
            }
            setProviderName(currentProviderName);

            // In Web Forms, loginInfo is obtained directly from OwinContext after callback.
            // In React, we assume backend has processed the callback and either
            // 1. Redirected with all info in query params.
            // 2. We make an API call to fetch the info using a temporary key/code from query params.
            // Here, we simulate fetching it or getting it from URL.
            const loginInfo = await IdentityHelper.GetExternalLoginInfo(
                searchParams,
                IdentityHelper.XsrfKey,
                userId // If authenticated, pass userId for linking check
            );

            if (!loginInfo || !loginInfo.Login) {
                redirectOnFail();
                setIsLoading(false);
                return;
            }

            setProviderAccountKey(loginInfo.Login.ProviderKey);

            // Simulate the manager.Find(loginInfo.Login) logic
            const user = await apiService.findUser(loginInfo.Login);

            if (user) {
                // User found, sign in
                const signInResult = await apiService.signInUser(user, false, false);
                if (signInResult.success) {
                    IdentityHelper.redirectToReturnUrl(returnUrl, navigate);
                } else {
                    setErrors(["Failed to sign in user."]);
                    redirectOnFail();
                }
            } else if (isAuthenticated) {
                // User is authenticated, but no external login linked yet. Link the login.
                // Apply Xsrf check when linking: In React, this is handled by backend API security
                // For demonstration, we directly proceed to add login.
                const addLoginResult = await apiService.addLoginToUser(userId, loginInfo.Login);
                if (addLoginResult.succeeded) {
                    IdentityHelper.redirectToReturnUrl(returnUrl, navigate);
                } else {
                    setErrors(addLoginResult.errors.map(err => err.Description || err));
                    // The original code `return;` here, implying not redirecting.
                    // If errors, stay on page to show errors.
                }
            } else {
                // User not found and not authenticated, propose registration
                setEmail(loginInfo.Email || '');
            }
            setIsLoading(false);
        };

        processExternalLogin();
    }, [isAuthenticated, userId, navigate, location.search, returnUrl, searchParams]); // Dependencies

    const handleEmailChange = (e) => {
        setEmail(e.target.value);
    };

    const handleLoginClick = async (e) => {
        e.preventDefault(); // Prevent default form submission
        setErrors([]); // Clear previous errors

        if (!email) {
            setErrors(["Email is required."]);
            return;
        }

        setIsLoading(true);

        const newUser = { userName: email, email: email };
        const loginInfo = await IdentityHelper.GetExternalLoginInfo(searchParams, IdentityHelper.XsrfKey, userId);
        
        if (!loginInfo || !loginInfo.Login) {
            setErrors(["External login information is missing or invalid. Please try again."]);
            setIsLoading(false);
            return;
        }

        const createResult = await apiService.createUser(newUser, loginInfo.Login);

        if (createResult.succeeded) {
            const signInResult = await apiService.signInUser(newUser, false, false);
            if (signInResult.success) {
                IdentityHelper.redirectToReturnUrl(returnUrl, navigate);
            } else {
                setErrors(["Account created, but failed to sign in."]);
            }
        } else {
            setErrors(createResult.errors.map(err => err.Description || err));
        }
        setIsLoading(false);
    };

    if (isLoading) {
        return <div className="register-external-login-container">Loading...</div>;
    }

    return (
        <div className="register-external-login-container">
            <h3>Register with your {providerName} account</h3>

            <div className="info-section">
                You've successfully authenticated with <strong>{providerName}</strong>.
                Please enter an email address for this site below and click the Register button to complete the registration.
            </div>

            <form onSubmit={handleLoginClick} className="register-form">
                {errors.length > 0 && (
                    <div className="error-messages">
                        <ul>
                            {errors.map((error, index) => (
                                <li key={index}>{error}</li>
                            ))}
                        </ul>
                    </div>
                )}

                <div className="form-group">
                    <label htmlFor="email">Email</label>
                    <input
                        type="email"
                        id="email"
                        value={email}
                        onChange={handleEmailChange}
                        required
                        className="form-control"
                    />
                </div>

                <div className="form-group">
                    <button type="submit" className="btn btn-primary">Register</button>
                </div>
            </form>
        </div>
    );
}

export default RegisterExternalLogin;