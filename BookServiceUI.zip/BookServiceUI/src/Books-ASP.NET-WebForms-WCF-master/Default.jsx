import React, { useState, useEffect, useCallback } from 'react';
import './Default.css';

// Mock API service to simulate backend calls
// In a real application, these would be actual fetch/axios calls to your API
const mockApiService = {
  getCategoryList: async () => {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 300));
    return [
      { CategoryId: 0, CategoryName: "All" }, // Add 'All' option for dropdown
      { CategoryId: 1, CategoryName: "Fiction" },
      { CategoryId: 2, CategoryName: "Science" },
      { CategoryId: 3, CategoryName: "History" },
      { CategoryId: 4, CategoryName: "Fantasy" },
    ];
  },
  getDetailedBookList: async (filters = {}) => {
    await new Promise(resolve => setTimeout(resolve, 500));
    const allBooks = [
      { ISBN: "978-0321765723", Title: "The Great Gatsby", Author: { FirstName: "F. Scott", LastName: "Fitzgerald" }, Publisher: { PublisherName: "Scribner" }, Category: { CategoryName: "Fiction" } },
      { ISBN: "978-0743273565", Title: "1984", Author: { FirstName: "George", LastName: "Orwell" }, Publisher: { PublisherName: "Signet Classics" }, Category: { CategoryName: "Fiction" } },
      { ISBN: "978-0590353427", Title: "Harry Potter and the Sorcerer's Stone", Author: { FirstName: "J.K.", LastName: "Rowling" }, Publisher: { PublisherName: "Scholastic" }, Category: { CategoryName: "Fantasy" } },
      { ISBN: "978-0743273566", Title: "Cosmos", Author: { FirstName: "Carl", LastName: "Sagan" }, Publisher: { PublisherName: "Ballantine Books" }, Category: { CategoryName: "Science" } },
      { ISBN: "978-0385504201", Title: "Sapiens: A Brief History of Humankind", Author: { FirstName: "Yuval Noah", LastName: "Harari" }, Publisher: { PublisherName: "Harper" }, Category: { CategoryName: "History" } },
      { ISBN: "978-0141182803", Title: "Pride and Prejudice", Author: { FirstName: "Jane", LastName: "Austen" }, Publisher: { PublisherName: "Penguin Classics" }, Category: { CategoryName: "Fiction" } },
    ];

    let filteredBooks = [...allBooks];

    if (filters.searchKeyword && filters.searchCriteria) {
      const keyword = filters.searchKeyword.toLowerCase();
      switch (filters.searchCriteria) {
        case "ISBN":
          filteredBooks = filteredBooks.filter(b => b.ISBN.toLowerCase().includes(keyword));
          break;
        case "Title":
          filteredBooks = filteredBooks.filter(b => b.Title.toLowerCase().includes(keyword));
          break;
        case "Author":
          filteredBooks = filteredBooks.filter(b => {
            const authorFullName = `${b.Author.FirstName.toLowerCase()} ${b.Author.LastName.toLowerCase()}`;
            const searchNames = keyword.split(' ');
            return searchNames.every(namePart => authorFullName.includes(namePart));
          });
          break;
        case "Publisher":
          filteredBooks = filteredBooks.filter(b => b.Publisher.PublisherName.toLowerCase().includes(keyword));
          break;
        default:
          break;
      }
    }

    if (filters.category && filters.category !== "All") {
      filteredBooks = filteredBooks.filter(b => b.Category.CategoryName === filters.category);
    }

    return filteredBooks;
  },
  addDetailedBook: async (book) => {
    await new Promise(resolve => setTimeout(resolve, 300));
    console.log("Adding book:", book);
    // In a real app, you'd send this to the backend.
    // For mock, we just confirm success.
    return { success: true, message: "Book added successfully!" };
  }
};

const BooksPage = () => {
  // State for search section
  const [searchKeyword, setSearchKeyword] = useState('');
  const [criteria, setCriteria] = useState('ISBN'); // Default criteria
  const [selectedCategory, setSelectedCategory] = useState('All');

  // State for data lists
  const [categories, setCategories] = useState([]);
  const [books, setBooks] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  // State for new book form
  const [newBookForm, setNewBookForm] = useState({
    isbn: '',
    title: '',
    author: '',
    publisher: '',
    category: ''
  });

  // State for validation errors
  const [validationErrors, setValidationErrors] = useState({});
  const [formSummaryErrors, setFormSummaryErrors] = useState([]);

  // Fetch initial data (categories and books) on component mount
  const fetchBooksAndCategories = useCallback(async (filters = {}) => {
    setIsLoading(true);
    setError(null);
    try {
      const fetchedCategories = await mockApiService.getCategoryList();
      setCategories(fetchedCategories);

      // The ASP.NET code initially loads all books, then filters client-side or re-fetches.
      // For React, we'll implement a `fetchBooksAndCategories` function that can accept filters
      // and call the mock API to get pre-filtered data, mimicking server-side filtering.
      const fetchedBooks = await mockApiService.getDetailedBookList(filters);
      setBooks(fetchedBooks);
    } catch (err) {
      setError("Failed to load data: " + err.message);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchBooksAndCategories();
  }, [fetchBooksAndCategories]); // Dependency on fetchBooksAndCategories to re-run if it changes (though it's useCallback'd)

  // Handlers for search section
  const handleSearchKeywordChange = (e) => setSearchKeyword(e.target.value);
  const handleCriteriaChange = (e) => setCriteria(e.target.value);
  const handleCategorySelectChange = (e) => setSelectedCategory(e.target.value);

  const handleSearchClick = async () => {
    // Logic similar to searchButton_Click
    const filters = {
      searchKeyword: searchKeyword,
      searchCriteria: criteria,
      category: selectedCategory
    };
    await fetchBooksAndCategories(filters);
  };

  // Handlers for new book form
  const handleNewBookFormChange = (e) => {
    const { name, value } = e.target;
    setNewBookForm(prev => ({ ...prev, [name]: value }));
    // Clear error for the field as user types
    if (validationErrors[name]) {
      setValidationErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[name];
        return newErrors;
      });
    }
  };

  const validateNewBookForm = () => {
    const errors = {};
    if (!newBookForm.isbn.trim()) errors.isbn = "ISBN is required.";
    if (!newBookForm.title.trim()) errors.title = "Title is required.";
    if (!newBookForm.author.trim()) errors.author = "Author is required.";
    if (!newBookForm.publisher.trim()) errors.publisher = "Publisher is required.";
    if (!newBookForm.category.trim()) errors.category = "Category is required.";

    setValidationErrors(errors);
    setFormSummaryErrors(Object.values(errors));
    return Object.keys(errors).length === 0;
  };

  const handleNewBookSubmit = async (e) => {
    e.preventDefault(); // Prevent default form submission
    // Logic similar to newBookButton_Click
    if (validateNewBookForm()) {
      try {
        const authorNames = newBookForm.author.trim().split(' ');
        const bookToAdd = {
          ISBN: newBookForm.isbn.trim(),
          Title: newBookForm.title.trim(),
          Author: {
            FirstName: authorNames[0] || '',
            LastName: authorNames.length > 1 ? authorNames[authorNames.length - 1] : ''
          },
          Publisher: {
            PublisherName: newBookForm.publisher.trim()
          },
          Category: {
            CategoryName: newBookForm.category.trim()
          }
        };

        // Submit book via API
        await mockApiService.addDetailedBook(bookToAdd);

        // Reload table content
        await fetchBooksAndCategories();

        // Clear the form
        setNewBookForm({
          isbn: '',
          title: '',
          author: '',
          publisher: '',
          category: ''
        });
        setFormSummaryErrors([]); // Clear summary errors on successful submission
      } catch (err) {
        setFormSummaryErrors(["Failed to add book: " + err.message]);
      }
    }
  };

  return (
    <div className="books-page">
      <h1>Books Management</h1>

      <section className="search-section">
        <h2>Search Books</h2>
        <div className="form-group">
          <label htmlFor="searchTxtBox">Search Keyword:</label>
          <input
            type="text"
            id="searchTxtBox"
            name="searchTxtBox"
            value={searchKeyword}
            onChange={handleSearchKeywordChange}
            placeholder="Enter keyword..."
          />
        </div>

        <div className="form-group">
          <label htmlFor="criteriaDDL">Search Criteria:</label>
          <select id="criteriaDDL" name="criteriaDDL" value={criteria} onChange={handleCriteriaChange}>
            <option value="ISBN">ISBN</option>
            <option value="Title">Title</option>
            <option value="Author">Author</option>
            <option value="Publisher">Publisher</option>
          </select>
        </div>

        <div className="form-group">
          <label htmlFor="catDDL">Category:</label>
          <select id="catDDL" name="catDDL" value={selectedCategory} onChange={handleCategorySelectChange}>
            {categories.map(cat => (
              <option key={cat.CategoryId} value={cat.CategoryName}>
                {cat.CategoryName}
              </option>
            ))}
          </select>
        </div>

        <button type="button" onClick={handleSearchClick} className="search-button">
          Search Books
        </button>
      </section>

      <section className="books-list-section">
        <h2>Book Details</h2>
        {isLoading && <p>Loading books...</p>}
        {error && <p className="error-message">{error}</p>}
        {!isLoading && !error && (
          books.length > 0 ? (
            <div className="books-table-container">
              <table>
                <thead>
                  <tr>
                    <th>ISBN</th>
                    <th>Title</th>
                    <th>Author</th>
                    <th>Publisher</th>
                    <th>Category</th>
                  </tr>
                </thead>
                <tbody>
                  {books.map((book, index) => (
                    <tr key={book.ISBN || index}> {/* Using ISBN as key if unique, otherwise index */}
                      <td>{book.ISBN}</td>
                      <td>{book.Title}</td>
                      <td>{book.Author.FirstName} {book.Author.LastName}</td>
                      <td>{book.Publisher.PublisherName}</td>
                      <td>{book.Category.CategoryName}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p>No books found.</p>
          )
        )}
      </section>

      <section className="new-book-section">
        <h2>Add New Book</h2>
        <form onSubmit={handleNewBookSubmit}>
          <div className="form-group">
            <label htmlFor="isbnTxtBox">ISBN:</label>
            <input
              type="text"
              id="isbnTxtBox"
              name="isbn"
              value={newBookForm.isbn}
              onChange={handleNewBookFormChange}
              className={validationErrors.isbn ? 'input-error' : ''}
              maxLength={13} // Assuming ISBN-13
            />
            {validationErrors.isbn && <span className="error-message">{validationErrors.isbn}</span>}
          </div>

          <div className="form-group">
            <label htmlFor="titleTxtBox">Title:</label>
            <input
              type="text"
              id="titleTxtBox"
              name="title"
              value={newBookForm.title}
              onChange={handleNewBookFormChange}
              className={validationErrors.title ? 'input-error' : ''}
            />
            {validationErrors.title && <span className="error-message">{validationErrors.title}</span>}
          </div>

          <div className="form-group">
            <label htmlFor="authorTxtBox">Author (First Last):</label>
            <input
              type="text"
              id="authorTxtBox"
              name="author"
              value={newBookForm.author}
              onChange={handleNewBookFormChange}
              className={validationErrors.author ? 'input-error' : ''}
            />
            {validationErrors.author && <span className="error-message">{validationErrors.author}</span>}
          </div>

          <div className="form-group">
            <label htmlFor="publisherTxtBox">Publisher:</label>
            <input
              type="text"
              id="publisherTxtBox"
              name="publisher"
              value={newBookForm.publisher}
              onChange={handleNewBookFormChange}
              className={validationErrors.publisher ? 'input-error' : ''}
            />
            {validationErrors.publisher && <span className="error-message">{validationErrors.publisher}</span>}
          </div>

          <div className="form-group">
            <label htmlFor="categoryTxtBox">Category:</label>
            <input
              type="text"
              id="categoryTxtBox"
              name="category"
              value={newBookForm.category}
              onChange={handleNewBookFormChange}
              className={validationErrors.category ? 'input-error' : ''}
            />
            {validationErrors.category && <span className="error-message">{validationErrors.category}</span>}
          </div>

          <button type="submit" className="new-book-button">
            Add New Book
          </button>

          {/* ValidationSummary equivalent */}
          {formSummaryErrors.length > 0 && (
            <div className="validation-summary">
              <h3>Please correct the following errors:</h3>
              <ul>
                {formSummaryErrors.map((err, index) => (
                  <li key={index}>{err}</li>
                ))}
              </ul>
            </div>
          )}
        </form>
      </section>
    </div>
  );
};

export default BooksPage;

// --- RESOURCE MANAGEMENT STRATEGY ---
// For string resources (like labels, button texts, validation messages),
// they are currently hardcoded in the JSX.
//
// For localization in a React app, consider these strategies:
// 1. Context API: Store language and translated strings in a React Context.
//    Components can then consume this context.
// 2. Libraries: Use dedicated internationalization (i18n) libraries like:
//    - `react-i18next`: A popular choice, based on i18next. It allows managing translations
//      in JSON files (similar concept to .resx files) and provides hooks/components
//      for translation.
//    - `FormatJS` / `react-intl`: Another robust option from Yahoo, providing components
//      and APIs for internationalization.
//
// Example (using a hypothetical `useTranslation` hook):
// import { useTranslation } from 'react-i18next';
// const { t } = useTranslation();
// <label htmlFor="isbnTxtBox">{t('isbnLabel')}:</label>
//
// Images would typically be placed in the `public` folder or imported
// and referenced directly in the JSX/CSS.
// 
// --- NAVIGATION STRATEGY ---
// Navigation in React applications is typically handled by `React Router`.
// Once a book is added, the ASP.NET app "reloads" the table, which means
// fetching new data for the current view.
// In React, this is achieved by calling `fetchBooksAndCategories()` again,
// which updates the `books` state, causing the component to re-render the table.
// If there was a need to navigate to a *different* page (e.g., a "Book Details" page
// after adding a book), you would use `useNavigate` hook from `react-router-dom`:
//
// import { useNavigate } from 'react-router-dom';
// const navigate = useNavigate();
// navigate('/books/newly-added-book-id'); // Example: navigate to a book details page
//
// In this specific case, the `newBookButton_Click` only updates the list on the same page,
// so re-fetching the list is the correct React equivalent.