import React from 'react';
import { Link } from 'react-router-dom';
import './ResetPasswordConfirmation.css';

const ResetPasswordConfirmation = () => {
  // The ASP.NET HyperLink 'login' would typically have 'Text' and 'NavigateUrl' properties.
  // We'll assume these values for translation to React.
  // In a real application, confirmation messages and link texts would often
  // come from a localization system (e.g., i18n library like react-i18next)
  // or a context API for managing global application text resources.
  // For this example, they are hardcoded as per the assumption.

  // Placeholder for external calls or complex logic if it were present in the C#
  // For this specific simple confirmation page, no complex logic or API calls
  // are indicated by the provided ASP.NET files.
  //
  // useEffect(() => {
  //   // Example: If the page needed to log a confirmation event to an analytics service
  //   // or fetch some post-confirmation status:
  //   // const logConfirmationEvent = async () => {
  //   //   try {
  //   //     await fetch('/api/logPasswordConfirmation', { method: 'POST' });
  //   //     console.log('Password reset confirmation logged.');
  //   //   } catch (error) {
  //   //     console.error('Failed to log confirmation:', error);
  //   //   }
  //   // };
  //   // logConfirmationEvent();
  // }, []);

  // Assuming the 'login' HyperLink's Text property was "Click here to log in"
  const loginLinkText = "Click here to log in";
  // Assuming the 'login' HyperLink's NavigateUrl property pointed to the login page (e.g., "~/Account/Login")
  const loginPath = "/login"; // Mapped to React Router path

  return (
    <div className="reset-password-confirmation-container">
      <h2 className="confirmation-title">Password Reset Confirmed</h2>
      <p className="confirmation-message">
        Your password has been reset successfully. You can now log in with your new password.
      </p>
      <div className="login-link-wrapper">
        {/* The ASP.NET HyperLink control 'login' is translated to a React Router Link component */}
        <Link to={loginPath} className="login-link">
          {loginLinkText}
        </Link>
      </div>
      {/* Any other UI elements from the original .aspx page would be added here */}
    </div>
  );
};

export default ResetPasswordConfirmation;