import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import './TwoFactorAuthenticationSignIn.css';

// Placeholder for API interactions (replace with actual fetch/axios calls to your backend)
const api = {
    // In a real application, the user's session/token would be implicitly managed by the browser
    // (e.g., via cookies) or explicitly sent in headers (e.g., Authorization: Bearer token).
    // The backend would use this to identify the user for 2FA actions.

    /**
     * Fetches valid two-factor authentication providers for the current unauthenticated but verified user.
     * This typically happens after the user has successfully entered username/password and
     * the system determined 2FA is required.
     * @returns {Promise<string[]>} A list of available 2FA provider names (e.g., "Email", "Phone").
     */
    getValidTwoFactorProviders: async () => {
        // Replace with actual API call:
        // const response = await fetch('/api/account/twofactorproviders', {
        //     headers: { 'Authorization': `Bearer ${yourAuthToken}` } // Example: if using token-based auth
        // });
        // if (!response.ok) {
        //     throw new Error('Failed to fetch 2FA providers');
        // }
        // return response.json();

        // Simulate API call success with mock data
        return new Promise(resolve => setTimeout(() => resolve(['Email', 'Phone']), 500));
        // Example if no providers or user not found (return empty array or throw error):
        // return new Promise(resolve => setTimeout(() => resolve([]), 500));
    },

    /**
     * Sends a two-factor authentication code to the user via the selected provider.
     * @param {string} provider The selected 2FA provider (e.g., "Email", "Phone").
     * @returns {Promise<boolean>} True if the code was successfully sent, false otherwise.
     */
    sendTwoFactorCode: async (provider) => {
        console.log(`[API] Request to send code via: ${provider}`);
        // Replace with actual API call:
        // const response = await fetch('/api/account/sendtwofactorcode', {
        //     method: 'POST',
        //     headers: { 'Content-Type': 'application/json', /* auth headers */ },
        //     body: JSON.stringify({ provider })
        // });
        // return response.ok; // Check for success status (e.g., 200 OK)

        return new Promise(resolve => setTimeout(() => resolve(true), 1000)); // Simulate success
    },

    /**
     * Verifies the two-factor authentication code entered by the user.
     * @param {string} provider The selected 2FA provider.
     * @param {string} code The 2FA code entered by the user.
     * @param {boolean} isPersistent Whether the sign-in cookie should persist (RememberMe).
     * @param {boolean} rememberBrowser Whether the browser should be remembered for 2FA.
     * @returns {Promise<string>} Sign-in status: 'success', 'lockedout', 'failure'.
     */
    twoFactorSignIn: async (provider, code, isPersistent, rememberBrowser) => {
        console.log(`[API] Request to verify code: ${code} for ${provider}, isPersistent: ${isPersistent}, rememberBrowser: ${rememberBrowser}`);
        // Replace with actual API call:
        // const response = await fetch('/api/account/twofactorsignin', {
        //     method: 'POST',
        //     headers: { 'Content-Type': 'application/json', /* auth headers */ },
        //     body: JSON.stringify({ provider, code, isPersistent, rememberBrowser })
        // });
        // const data = await response.json(); // Backend should return a status like { status: "success" }
        // return data.status;

        // Simulate backend responses
        if (code === '123456') { // Success case
            return new Promise(resolve => setTimeout(() => resolve('success'), 1000));
        } else if (code === 'locked') { // Locked out case
            return new Promise(resolve => setTimeout(() => resolve('lockedout'), 1000));
        } else { // Failure case
            return new Promise(resolve => setTimeout(() => resolve('failure'), 1000));
        }
    }
};

const TwoFactorAuthenticationSignIn = () => {
    const navigate = useNavigate();
    const [searchParams] = useSearchParams();

    // State variables for UI and data
    const [providers, setProviders] = useState([]);
    const [selectedProvider, setSelectedProvider] = useState('');
    const [code, setCode] = useState('');
    const [rememberBrowser, setRememberBrowser] = useState(false);
    const [showSendCodeSection, setShowSendCodeSection] = useState(true); // Corresponds to 'sendcode' PlaceHolder
    const [showVerifyCodeSection, setShowVerifyCodeSection] = useState(false); // Corresponds to 'verifycode' PlaceHolder
    const [errorMessage, setErrorMessage] = useState(''); // Corresponds to 'FailureText'
    const [showError, setShowError] = useState(false); // Corresponds to 'ErrorMessage.Visible'
    const [isLoading, setIsLoading] = useState(false); // For managing loading state and disabling buttons

    // Equivalent to ASP.NET Page_Load event
    useEffect(() => {
        const loadPageData = async () => {
            setIsLoading(true);
            try {
                // In ASP.NET, GetVerifiedUserId would implicitly check the session.
                // Here, we assume the backend API for providers handles the user context and redirects if needed.
                const userProviders = await api.getValidTwoFactorProviders();

                if (!userProviders || userProviders.length === 0) {
                    // No providers found or user not eligible for 2FA (e.g., session expired or user not verified)
                    // Redirect to an error page or login page as per ASP.NET `Response.Redirect("/Account/Error", true);`
                    navigate('/account/error'); // Adjust path as per your React Router setup
                    return;
                }
                setProviders(userProviders);
                if (userProviders.length > 0) {
                    setSelectedProvider(userProviders[0]); // Select the first provider by default
                }
            } catch (error) {
                console.error("Failed to load 2FA providers:", error);
                setErrorMessage("Failed to load two-factor authentication options. Please try again.");
                setShowError(true);
                // Optionally redirect to error page if critical
                // navigate('/account/error');
            } finally {
                setIsLoading(false);
            }
        };
        loadPageData();
    }, [navigate]); // Dependency array includes navigate to ensure it's stable and ESLint happy

    // Handle form submission for selecting provider (ProviderSubmit_Click)
    const handleProviderSubmit = async (e) => {
        e.preventDefault();
        if (!selectedProvider) {
            setErrorMessage("Please select a provider.");
            setShowError(true);
            return;
        }

        setIsLoading(true);
        setErrorMessage(''); // Clear previous errors
        setShowError(false);

        try {
            const success = await api.sendTwoFactorCode(selectedProvider);
            if (success) {
                setShowSendCodeSection(false); // Hide 'sendcode'
                setShowVerifyCodeSection(true); // Show 'verifycode'
            } else {
                setErrorMessage("Failed to send two-factor code. Please try again.");
                setShowError(true);
                // ASP.NET example redirects to error page on failure to send code, replicate if desired
                // navigate('/account/error');
            }
        } catch (error) {
            console.error("Error sending 2FA code:", error);
            setErrorMessage("An unexpected error occurred while sending the code.");
            setShowError(true);
        } finally {
            setIsLoading(false);
        }
    };

    // Handle form submission for verifying code (CodeSubmit_Click)
    const handleCodeSubmit = async (e) => {
        e.preventDefault();
        if (!code) {
            setErrorMessage("Please enter the two-factor authentication code.");
            setShowError(true);
            return;
        }

        setIsLoading(true);
        setErrorMessage(''); // Clear previous errors
        setShowError(false);

        // Get rememberMe from query string: `bool.TryParse(Request.QueryString["RememberMe"], out rememberMe);`
        const rememberMe = searchParams.get('RememberMe') === 'true';
        // Get returnUrl from query string: `Request.QueryString["ReturnUrl"]`
        const returnUrl = searchParams.get('ReturnUrl') || '/'; // Default to home page if no return URL

        try {
            const result = await api.twoFactorSignIn(selectedProvider, code, rememberMe, rememberBrowser);

            switch (result) {
                case 'success':
                    // IdentityHelper.RedirectToReturnUrl(Request.QueryString["ReturnUrl"], Response);
                    navigate(returnUrl);
                    break;
                case 'lockedout':
                    // Response.Redirect("/Account/Lockout");
                    navigate('/account/lockout'); // Adjust path as per your React Router setup
                    break;
                case 'failure':
                default:
                    // FailureText.Text = "Invalid code"; ErrorMessage.Visible = true;
                    setErrorMessage("Invalid code");
                    setShowError(true);
                    break;
            }
        } catch (error) {
            console.error("Error verifying 2FA code:", error);
            setErrorMessage("An unexpected error occurred during verification.");
            setShowError(true);
        } finally {
            setIsLoading(false);
        }
    };

    if (isLoading && providers.length === 0 && showSendCodeSection) {
        return <div className="loading-state">Loading two-factor options...</div>;
    }

    return (
        <div className="two-factor-auth-container">
            <h1>Two-Factor Authentication</h1>

            {/* ErrorMessage and FailureText equivalent */}
            {showError && (
                <div className="error-message-box" role="alert">
                    {errorMessage}
                </div>
            )}

            {/* sendcode PlaceHolder equivalent */}
            {showSendCodeSection && (
                <form onSubmit={handleProviderSubmit} className="send-code-form">
                    <p>Select a two-factor authentication provider:</p>
                    <div className="form-group">
                        <label htmlFor="providers" className="sr-only">Select Provider</label> {/* Visually hidden label */}
                        <select
                            id="providers"
                            className="form-control"
                            value={selectedProvider}
                            onChange={(e) => setSelectedProvider(e.target.value)}
                            disabled={isLoading || providers.length === 0}
                        >
                            {providers.length > 0 ? (
                                providers.map((provider) => (
                                    <option key={provider} value={provider}>
                                        {provider}
                                    </option>
                                ))
                            ) : (
                                <option value="">No providers available</option>
                            )}
                        </select>
                    </div>
                    {/* ProviderSubmit Button equivalent */}
                    <button type="submit" className="btn btn-primary" disabled={isLoading || providers.length === 0}>
                        {isLoading ? 'Sending...' : 'Submit'}
                    </button>
                </form>
            )}

            {/* verifycode PlaceHolder equivalent */}
            {showVerifyCodeSection && (
                <form onSubmit={handleCodeSubmit} className="verify-code-form">
                    {/* SelectedProvider HiddenField equivalent, value handled by state */}
                    <input type="hidden" value={selectedProvider} />

                    <p>Enter the code sent to your {selectedProvider || 'selected provider'}.</p>
                    <div className="form-group">
                        <label htmlFor="code">Code:</label>
                        <input
                            type="text"
                            id="code"
                            className="form-control"
                            value={code}
                            onChange={(e) => setCode(e.target.value)}
                            disabled={isLoading}
                            autoComplete="one-time-code" // Hint for autofill on mobile
                        />
                    </div>
                    <div className="form-group form-check">
                        {/* RememberBrowser CheckBox equivalent */}
                        <input
                            type="checkbox"
                            id="rememberBrowser"
                            className="form-check-input"
                            checked={rememberBrowser}
                            onChange={(e) => setRememberBrowser(e.target.checked)}
                            disabled={isLoading}
                        />
                        <label htmlFor="rememberBrowser" className="form-check-label">Remember browser</label>
                    </div>
                    {/* CodeSubmit Button equivalent */}
                    <button type="submit" className="btn btn-success" disabled={isLoading}>
                        {isLoading ? 'Verifying...' : 'Submit Code'}
                    </button>
                </form>
            )}
        </div>
    );
};

export default TwoFactorAuthenticationSignIn;
// Strategy for .resx resources:
// For simple strings like "Invalid code" or "Select a provider", they are hardcoded directly in the JSX.
// For a multi-language application, consider using an i18n library like `react-i18next`.
// E.g., `import { useTranslation } from 'react-i18next'; const { t } = useTranslation(); <p>{t('twoFactorAuth.selectProvider')}</p>`
// Images and other assets would be handled by React's build process (e.g., imported directly or served from a public folder).