import React, { useEffect, useState } from 'react';
import { useLocation, Link } from 'react-router-dom';
import './Confirm.css';

// Placeholder for API utility (e.g., using axios or fetch)
const apiClient = {
  post: async (url, data) => {
    // In a real application, you would make an actual API call here.
    // Example using fetch:
    /*
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    });
    if (!response.ok) {
      throw new Error('API call failed');
    }
    return response.json();
    */

    // Mock API call for demonstration:
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        // Simulate success or failure based on some condition or random
        if (data.userId && data.code) { // Basic check for validity
          resolve({ succeeded: true });
        } else {
          reject(new Error('Invalid user ID or confirmation code.'));
        }
      }, 1000); // Simulate network delay
    });
  },
};

const ConfirmAccount = () => {
  const [isSuccess, setIsSuccess] = useState(null); // null: loading, true: success, false: error
  const [isLoading, setIsLoading] = useState(true);
  const [message, setMessage] = useState('');

  const location = useLocation();

  useEffect(() => {
    const confirmEmail = async () => {
      const queryParams = new URLSearchParams(location.search);
      const code = queryParams.get('code');
      const userId = queryParams.get('userId'); // Assuming userId is passed as 'userId' in query string

      if (!code || !userId) {
        setIsSuccess(false);
        setMessage('Invalid confirmation link. Missing code or user ID.');
        setIsLoading(false);
        return;
      }

      try {
        // This is where the actual API call to your backend would happen.
        // The backend would then use ASP.NET Identity to confirm the email.
        // Example: POST to /api/account/confirm-email with userId and code
        const result = await apiClient.post('/api/account/confirm-email', { userId, code });

        if (result.succeeded) {
          setIsSuccess(true);
          setMessage('Thank you for confirming your account.');
        } else {
          setIsSuccess(false);
          setMessage('Confirm email link failed. Please try again or request a new link.');
        }
      } catch (error) {
        setIsSuccess(false);
        setMessage(`An error occurred: ${error.message || 'Unable to confirm your account.'}`);
      } finally {
        setIsLoading(false);
      }
    };

    confirmEmail();
  }, [location.search]);

  if (isLoading) {
    return (
      <div className="confirm-account-container">
        <div className="confirm-account-loading-panel">
          <p>Confirming your account...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="confirm-account-container">
      {isSuccess ? (
        <div id="successPanel" className="confirm-account-panel success">
          <p>{message}</p>
          <p>
            <Link to="/login" id="login" className="confirm-account-link">Click here to Log in</Link>
          </p>
        </div>
      ) : (
        <div id="errorPanel" className="confirm-account-panel error">
          <p>{message || 'Confirm email link failed. Please try again.'}</p>
        </div>
      )}
    </div>
  );
};

export default ConfirmAccount;