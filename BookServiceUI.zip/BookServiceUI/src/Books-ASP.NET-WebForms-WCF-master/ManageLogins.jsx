import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import './ManageLogins.css';

// Type definition for a login info object (mimics UserLoginInfo)
/**
 * @typedef {Object} UserLoginInfo
 * @property {string} loginProvider - The name of the login provider (e.g., "Google", "Facebook").
 * @property {string} providerKey - The unique key from the provider for this user.
 */

const ManageLogins = () => {
    const navigate = useNavigate();
    const location = useLocation();

    /** @type {[UserLoginInfo[], React.Dispatch<React.SetStateAction<UserLoginInfo[]>>]} */
    const [logins, setLogins] = useState([]);
    const [successMessage, setSuccessMessage] = useState('');
    const [hasPassword, setHasPassword] = useState(false); // Mimics HasPassword logic
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState('');

    // In a real application, currentUserId would come from an authentication context or a global state manager
    const currentUserId = 'loggedInUser123'; // Placeholder for the current user's ID

    useEffect(() => {
        // Function to fetch login information and user password status
        const fetchUserData = async () => {
            setIsLoading(true);
            setError('');
            try {
                // --- API CALL PLACEHOLDER: Fetch User Logins ---
                // Replace with actual API call to your backend (e.g., /api/account/logins?userId=...)
                // This API should return an array of { loginProvider, providerKey } objects.
                // Example:
                // const response = await fetch(`/api/account/logins?userId=${currentUserId}`);
                // if (!response.ok) throw new Error('Failed to fetch logins');
                // const data = await response.json();
                const fetchedLogins = [
                    { loginProvider: 'Google', providerKey: 'googleUser123' },
                    { loginProvider: 'Facebook', providerKey: 'facebookUserXYZ' },
                ];
                setLogins(fetchedLogins);

                // --- API CALL PLACEHOLDER: Fetch User Password Status ---
                // Replace with actual API call to check if the user has a local password.
                // Example:
                // const passwordResponse = await fetch(`/api/account/hasPassword?userId=${currentUserId}`);
                // if (!passwordResponse.ok) throw new Error('Failed to fetch password status');
                // const passwordStatus = await passwordResponse.json(); // { hasPassword: true/false }
                const fetchedHasPassword = true; // Simulate user having a password
                setHasPassword(fetchedHasPassword);

            } catch (err) {
                setError(`Failed to load data: ${err.message}`);
            } finally {
                setIsLoading(false);
            }
        };

        fetchUserData();
    }, [currentUserId]); // Re-run if currentUserId changes (though typically it's static after login)

    useEffect(() => {
        // Check for success message in URL query parameters
        const params = new URLSearchParams(location.search);
        if (params.get('m') === 'RemoveLoginSuccess') {
            setSuccessMessage('The external login was removed.');
            // Optionally, clear the query parameter from the URL after displaying
            navigate(location.pathname, { replace: true });
        } else {
            setSuccessMessage('');
        }
    }, [location.search, navigate, location.pathname]);

    const handleRemoveLogin = async (loginProvider, providerKey) => {
        setIsLoading(true);
        setError('');
        try {
            // --- API CALL PLACEHOLDER: Remove Login ---
            // Replace with actual API call to your backend (e.g., /api/account/removeLogin)
            // This API should accept { userId, loginProvider, providerKey } and return success/failure.
            // Example:
            // const response = await fetch('/api/account/removeLogin', {
            //     method: 'POST',
            //     headers: { 'Content-Type': 'application/json' },
            //     body: JSON.stringify({ userId: currentUserId, loginProvider, providerKey }),
            // });
            // if (!response.ok) {
            //     const errorData = await response.json();
            //     throw new Error(errorData.message || 'Failed to remove login');
            // }

            // Simulate API success
            console.log(`Simulating removal of ${loginProvider} login for ${currentUserId}`);
            await new Promise(resolve => setTimeout(resolve, 500)); // Simulate network delay

            // After successful removal, simulate the signInManager.SignIn equivalent
            // In a React app, this might involve re-fetching user claims/profile from an auth endpoint
            // or simply triggering a state update. For now, we'll just refetch the logins list.

            // Navigate to trigger success message display
            navigate('/managelogins?m=RemoveLoginSuccess');

        } catch (err) {
            setError(`Error removing login: ${err.message}`);
        } finally {
            setIsLoading(false);
            // Re-fetch logins to update the UI
            // This re-renders the component and updates the list
            // The useEffect for `fetchUserData` might need to be re-triggered explicitly
            // or by changing a dependency if not already covered.
            // For simplicity, we'll re-fetch everything in the main effect's dependency.
            // Or, more efficiently, update the `logins` state directly.
            setLogins(currentLogins => currentLogins.filter(
                login => !(login.loginProvider === loginProvider && login.providerKey === providerKey)
            ));
        }
    };

    // Derived state for the "CanRemoveExternalLogins" logic
    // A login can be removed if there's more than one external login OR the user has a password.
    // This logic usually applies *per* button: if removing *this* login would leave 0 logins and no password, disable.
    const canRemoveAnyLogin = logins.length > 1 || hasPassword;

    if (isLoading) {
        return (
            <div className="manage-logins-container">
                <p>Loading logins...</p>
            </div>
        );
    }

    if (error) {
        return (
            <div className="manage-logins-container">
                <p className="error-message">{error}</p>
            </div>
        );
    }

    return (
        <div className="manage-logins-container">
            <h1>Manage Your External Logins</h1>

            {successMessage && (
                <div className="success-message-placeholder">
                    <p className="success-message">{successMessage}</p>
                </div>
            )}

            <h2>Registered Logins</h2>
            {logins.length === 0 ? (
                <p>No external logins registered.</p>
            ) : (
                <table className="logins-table">
                    <thead>
                        <tr>
                            <th>Provider</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        {logins.map((login) => (
                            <tr key={`${login.loginProvider}-${login.providerKey}`}>
                                <td>{login.loginProvider}</td>
                                <td>
                                    <button
                                        onClick={() => handleRemoveLogin(login.loginProvider, login.providerKey)}
                                        // Disable if this is the only login AND user has no password
                                        disabled={logins.length === 1 && !hasPassword}
                                        className="remove-button"
                                    >
                                        Remove
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            )}

            {!hasPassword && (
                <p className="warning-message">
                    You do not have a local password for this site. Add a local password
                    <a href="/add-password"> here</a>.
                </p>
            )}

            {logins.length === 1 && !hasPassword && (
                <p className="info-message">
                    You only have one external login and no local password. You must set a password
                    before you can remove this login.
                </p>
            )}

            <div className="localization-note">
                {/* Localization Note:
                    For a real application, strings like "Manage Your External Logins",
                    "The external login was removed.", "Provider", "Action", "Remove",
                    "No external logins registered.", "You do not have a local password...",
                    and "You only have one external login..."
                    should be managed using an internationalization (i18n) library
                    (e.g., react-i18next, formatjs) and pulled from resource files
                    or a translation service, similar to .resx in ASP.NET.
                */}
            </div>
        </div>
    );
};

export default ManageLogins;