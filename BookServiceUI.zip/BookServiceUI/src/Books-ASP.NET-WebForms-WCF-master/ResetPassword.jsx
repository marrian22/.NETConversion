import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import './ResetPassword.css'; // Import the CSS file

const ResetPasswordPage = () => {
    const navigate = useNavigate();
    const location = useLocation();

    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [errorMessage, setErrorMessage] = useState('');
    const [statusMessage, setStatusMessage] = useState(''); // Corresponds to StatusMessage in original
    const [resetCode, setResetCode] = useState('');

    useEffect(() => {
        // Equivalent to IdentityHelper.GetCodeFromRequest(Request)
        const params = new URLSearchParams(location.search);
        const code = params.get('code');
        if (code) {
            setResetCode(code);
            setErrorMessage(''); // Clear any previous error if code is found
        } else {
            setErrorMessage('An error has occurred: Password reset code is missing.');
        }
    }, [location.search]);

    const handleReset = async (e) => {
        e.preventDefault(); // Prevent default form submission

        setErrorMessage(''); // Clear previous errors
        setStatusMessage(''); // Clear previous status messages

        if (!resetCode) {
            setErrorMessage('An error has occurred: Password reset code is missing.');
            return;
        }

        if (password !== confirmPassword) {
            setErrorMessage('Password and confirmation password do not match.');
            return;
        }

        if (!email || !password) {
            setErrorMessage('Please fill in all required fields.');
            return;
        }

        try {
            // --- Placeholder for API call ---
            // This replaces the server-side logic involving ApplicationUserManager
            // You would typically make an API call to your backend here.
            // Example:
            // const response = await fetch('/api/account/resetpassword', {
            //     method: 'POST',
            //     headers: { 'Content-Type': 'application/json' },
            //     body: JSON.stringify({ userId: email, code: resetCode, newPassword: password })
            // });
            // const data = await response.json();

            // Simulate API response for successful reset
            // For actual implementation, replace with real API call
            const simulatedApiCall = new Promise((resolve, reject) => {
                setTimeout(() => {
                    if (email === "test@example.com" && resetCode === "validCode123") {
                        // Simulate successful reset
                        resolve({ succeeded: true });
                    } else if (email === "unknown@example.com") {
                        // Simulate user not found
                        resolve({ succeeded: false, errors: ["No user found"] });
                    } else {
                        // Simulate other errors
                        resolve({ succeeded: false, errors: ["Invalid code or email."] });
                    }
                }, 1000); // Simulate network delay
            });

            const result = await simulatedApiCall;
            // --- End Placeholder for API call ---

            if (result.succeeded) {
                // Equivalent to Response.Redirect("~/Account/ResetPasswordConfirmation")
                navigate('/resetpasswordconfirmation');
                return;
            } else {
                setErrorMessage(result.errors && result.errors.length > 0 ? result.errors[0] : 'An unknown error occurred.');
                return;
            }
        } catch (error) {
            console.error('Password reset failed:', error);
            setErrorMessage('An unexpected error occurred. Please try again.');
        }
    };

    return (
        <div className="reset-password-container">
            <h2>Reset Password</h2>
            {errorMessage && (
                <div className="error-message" role="alert">
                    {errorMessage}
                </div>
            )}
            {statusMessage && (
                <div className="status-message" role="alert">
                    {statusMessage}
                </div>
            )}
            <form onSubmit={handleReset} className="reset-password-form">
                <div className="form-group">
                    <label htmlFor="email">Email</label>
                    <input
                        type="email"
                        id="email"
                        className="form-control"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                        aria-describedby="email-help"
                    />
                    <small id="email-help" className="form-text text-muted">Enter the email associated with your account.</small>
                </div>
                <div className="form-group">
                    <label htmlFor="password">New Password</label>
                    <input
                        type="password"
                        id="password"
                        className="form-control"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                        aria-describedby="password-help"
                    />
                    <small id="password-help" className="form-text text-muted">
                        Passwords must be at least 6 characters, contain uppercase, lowercase, a digit, and a special character.
                    </small>
                </div>
                <div className="form-group">
                    <label htmlFor="confirmPassword">Confirm New Password</label>
                    <input
                        type="password"
                        id="confirmPassword"
                        className="form-control"
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        required
                    />
                </div>
                <button type="submit" className="btn btn-primary">Reset</button>
            </form>
            {/* Strategy for .resx resources:
                Hardcoded strings like "Reset Password", "Email", "New Password", etc.,
                can be externalized using an internationalization (i18n) library like react-i18next.
                For example: <h1>{t('resetPassword.title')}</h1>
                Images or other assets would be served from the public folder or an asset pipeline.
            */}
        </div>
    );
};

export default ResetPasswordPage;