import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './AddPhoneNumber.css'; // Import the CSS file

const AddPhoneNumber = () => {
    const [phoneNumber, setPhoneNumber] = useState('');
    const [errorMessage, setErrorMessage] = useState('');
    const navigate = useNavigate();

    // Placeholder for the API call to the backend.
    // This function would typically interact with your ASP.NET Core API
    // which handles the Identity management, token generation, and SMS sending.
    const addPhoneNumberApi = async (number) => {
        // --- START External call placeholder ---
        // In a real application, this would be an actual API call, e.g., using fetch or axios:
        // const response = await fetch('/api/account/generate-phone-token', {
        //     method: 'POST',
        //     headers: { 'Content-Type': 'application/json' },
        //     body: JSON.stringify({ phoneNumber: number })
        // });
        // if (!response.ok) {
        //     const errorData = await response.json();
        //     throw new Error(errorData.message || 'Failed to generate token and send SMS.');
        // }
        // return await response.json(); // Or just return success status

        // Simulating a successful API call for demonstration:
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                if (number && number.replace(/\D/g, '').length >= 10) { // Basic validation for 10+ digits
                    console.log(`Simulating API call: Generating token and sending SMS to ${number}`);
                    resolve({ success: true, message: "Security code sent successfully." });
                } else {
                    reject(new Error("Please enter a valid phone number (at least 10 digits)."));
                }
            }, 1000); // Simulate network delay
        });
        // --- END External call placeholder ---
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setErrorMessage(''); // Clear previous errors

        if (!phoneNumber.trim()) {
            setErrorMessage('Phone number cannot be empty.');
            return;
        }

        try {
            // Call the backend API
            await addPhoneNumberApi(phoneNumber);

            // --- START Navigation placeholder ---
            // Navigate to the verification page, passing the phone number as a query parameter.
            // This mirrors the `Response.Redirect` from ASP.NET.
            navigate(`/verifyphonenumber?phoneNumber=${encodeURIComponent(phoneNumber)}`);
            // --- END Navigation placeholder ---
        } catch (error) {
            console.error('Error adding phone number:', error);
            setErrorMessage(error.message || 'An unexpected error occurred.');
        }
    };

    return (
        <div className="add-phone-number-container">
            <h2>Add Phone Number</h2>
            {/* Error Message control equivalent */}
            {errorMessage && (
                <div className="error-message">{errorMessage}</div>
            )}
            <form onSubmit={handleSubmit} className="add-phone-number-form">
                <div className="form-group">
                    <label htmlFor="phoneNumberInput">Phone Number</label>
                    {/* PhoneNumber TextBox control equivalent */}
                    <input
                        type="tel" // Use type="tel" for phone numbers
                        id="phoneNumberInput"
                        className="form-control"
                        value={phoneNumber}
                        onChange={(e) => setPhoneNumber(e.target.value)}
                        placeholder="e.g., +15551234567"
                        required
                    />
                </div>
                {/* PhoneNumber_Click Button equivalent */}
                <button type="submit" className="btn btn-primary">
                    Send Security Code
                </button>
            </form>
            {/*
                Strategy to deal with .resx resources (hardcoded strings, localization):
                - For simple labels and messages like "Phone Number", "Send Security Code",
                  and error messages, they are currently hardcoded directly in the JSX.
                - For more complex applications requiring internationalization (i18n),
                  it's recommended to use a dedicated library like `i18next` or `react-intl`.
                  These libraries allow you to define translations in JSON files (similar to .resx)
                  and access them in your components using hooks (e.g., `useTranslation`).

                Example with i18next:
                import { useTranslation } from 'react-i18next';
                const { t } = useTranslation();
                // ...
                <label htmlFor="phoneNumberInput">{t('addPhoneNumber.labelPhoneNumber')}</label>
                <button type="submit">{t('addPhoneNumber.buttonSendCode')}</button>
                // For the message sent via SMS, it would also be retrieved from translations on the backend.
            */}
        </div>
    );
};

export default AddPhoneNumber;